var img_h4 = $('#img4').css("height");
var content_h4 = $('#contect4').css("height");
console.log(img_h4);
console.log(content_h4);